from setuptools import setup

setup(
    package_data={"review": ["templates/review", "static/review"]}
  )